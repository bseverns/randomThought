import processing.core.*; 
import processing.xml.*; 

import oscP5.*; 
import netP5.*; 
import processing.opengl.*; 
import processing.video.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class ppClient extends PApplet {

/*
 * oscP5broadcastClient by andreas schlegel
 * an osc broadcast client.
 * an example for broadcast server is located in the oscP5broadcaster exmaple.
 * oscP5 website at http://www.sojamo.de/oscP5
 */




float presenceSum = 0;

OscP5 oscP5;

/* a NetAddress contains the ip address and port number of a remote location in the network. */
NetAddress serverTown; 

public void setup() {
  size(screen.width, screen.height);
  background(0);
  frameRate(30);
 
  /* create a new instance of oscP5. 
   * 12000 is the port number you are listening for incoming osc messages.
   */
  oscP5 = new OscP5(this,12000);
  
  /* create a new NetAddress. a NetAddress is used when sending osc messages
   * with the oscP5.send method.
   */
  
  /* the address of the osc broadcast server */
  myBroadcastLocation = new NetAddress("127.0.0.1",32000);

}


public void draw() {
background(0);
}


public void actionTaken() {
  /* create a new OscMessage with an address pattern, in this case /test. */
  OscMessage myOscMessage = new OscMessage("score");
  /* add a value (an integer) to the OscMessage */
  myOscMessage.add(1);
  /* send the OscMessage to a remote location specified in myNetAddress */
  oscP5.send(myOscMessage, myBroadcastLocation);
}


public void keyPressed() {
  OscMessage m;
  switch(key) {
    case('c'):
      /* connect to the broadcaster */
      m = new OscMessage("/server/connect",new Object[0]);
      oscP5.flush(m,myBroadcastLocation);  
      break;
    case('d'):
      /* disconnect from the broadcaster */
      m = new OscMessage("/server/disconnect",new Object[0]);
      oscP5.flush(m,myBroadcastLocation);  
      break;

  }  
}

public void getScore(){
  fill(255);
  textSize(30);
  text("Player 1",screen.width/8,screen.height/6);
  text("Player 2",screen.width-(screen.width/4),screen.height/6);
  textSize(60);
  text(player1,screen.width/8,screen.height/4);
  text(player2,screen.width-(screen.width/4),screen.height/4);  
  if(x == 80 && direction == 1){
      player1++;
  }
  if(x == screen.width-80 && direction == -1){
      player2++;   
  }
  
}

/* incoming osc message are forwarded to the oscEvent method. */
public void oscEvent(OscMessage theOscMessage) {
  /* get and print the address pattern and the typetag of the received OscMessage */
  println("### received an osc message with addrpattern "+theOscMessage.addrPattern()+" and typetag "+theOscMessage.typetag());
  theOscMessage.print();
}



int numPixels;
int[] backgroundPixels;
Capture video;

public void runVideo() {

  if (video.available()) {
    arraycopy(video.pixels, backgroundPixels);
    video.read(); // Read a new video frame
    video.loadPixels(); // Make the pixels of video available

    presenceSum = 0.0f;

    for (int i = 0; i < numPixels; i++) { // For each pixel in the video frame...
      // Fetch the current color in that location, and also the color
      // of the background in that spot
      int currColor = video.pixels[i];
      int bkgdColor = backgroundPixels[i];
      // Extract the red, green, and blue components of the current pixel\u00d5s color
      int currR = (currColor >> 16) & 0xFF;
      int currG = (currColor >> 8) & 0xFF;
      int currB = currColor & 0xFF;
      // Extract the red, green, and blue components of the background pixel\u00d5s color
      int bkgdR = (bkgdColor >> 16) & 0xFF;
      int bkgdG = (bkgdColor >> 8) & 0xFF;
      int bkgdB = bkgdColor & 0xFF;
      // Compute the difference of the red, green, and blue values
      int diffR = abs(currR - bkgdR);
      int diffG = abs(currG - bkgdG);
      int diffB = abs(currB - bkgdB);

      presenceSum += (diffR + diffG + diffB);
    }
  }
  presenceSum = map(presenceSum, 0, 1000000, 1, 10);
  println(presenceSum);
}

public void stop()
{
  video.stop();
  super.stop();
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--hide-stop", "ppClient" });
  }
}
